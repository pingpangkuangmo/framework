package com.demo.kafka;

import kafka.client.ClientUtils;

public class Test {

	ClientUtils clientUtils;
}
